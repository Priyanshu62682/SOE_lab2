package q3;
import java.sql.*;
import java.util.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
public class faculty {
    
   private JFrame mainframe;
   private JPanel p;
   private JButton show,update,enter,newupdate,logout;
   private JTable table;
   private JScrollPane scollpane;
   private JTextField id,upatt,upmar;
   private JLabel l1,idmsg,record;
    static String funame,facultysub;
    private JScrollPane sp;
    

    faculty(String un) {
         funame=un;
        prepareGui();
        showGui();
        showdata();
        
    }
    private void prepareGui() {
        
        mainframe= new  JFrame("Faculty");
        p=new JPanel();
        mainframe.setContentPane(p);
        
        mainframe.setSize(1000,700);
        mainframe.setLayout(null);
        mainframe.setResizable(true);
        mainframe.addWindowListener(new  WindowAdapter() {

        public void windowCloser(WindowEvent e)
        {
             System.exit(0);
        }
        
        });
        show=new JButton("SHOW");
        show.setBounds(300, 50, 80, 40);
        show.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                showdata();    
            }

           });
        
         update=new JButton("UPDATE");
        update.setBounds(600, 50, 80, 40);
        update.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                //To change body of generated methods, choose Tools | Templates.
                sp.setVisible(false);
            table.setVisible(false);
                updatebtn();    
            }

            
           });
        logout=new JButton("logout");
        logout.setBounds(900, 610, 80, 30);
        logout.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

               logoff();
            }

            private void logoff() {
                login lg=new login();
                lg.showGui();
                mainframe.setVisible(false);
            }
        });
            l1=new JLabel("Enter ID");
            l1.setBounds(400,150, 80, 30);
            l1.setVisible(false);
            idmsg=new JLabel();
            idmsg.setBounds(400,200, 150, 30);
            idmsg.setVisible(false);
            id=new JTextField();
            id.setBounds(500,150, 80, 30);
            id.setVisible(false);
            enter=new JButton("Enetr");
            enter.setBounds(600,150,80,30);
            enter.setVisible(false);
            upatt=new JTextField("Enter Attendence");
            upatt.setBounds(300,200,150, 30);
            upatt.setVisible(false);
            upmar=new JTextField("Enter marks");
            upmar.setBounds(460,200,150, 30);
            upmar.setVisible(false);
            newupdate=new JButton("Update");
            newupdate.setBounds(610,200,80,30);
            newupdate.setVisible(false);
            record= new JLabel("Record Updated !!!!");
            record.setBounds(300,300, 150, 100);
            record.setVisible(false);
            
            p.add(record);
            p.add(newupdate);
            p.add(upatt);
            p.add(upmar);
        p.add(show);
        p.add(update); 
        mainframe.setVisible(true);
        
    }
    private void updatebtn() {
            sp.setVisible(false);
            table.setVisible(false);
            l1.setVisible(true);
            id.setVisible(true);
            
            
            enter.setVisible(true);
            enter.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    String uid=id.getText();
                    // System.out.println("Inside uppbtn "+uid);
                    if(uid.length()<10)
                    {
                        idmsg.setText("Enter Valid ID");
                        idmsg.setVisible(true);
                    }
                    else{
                    updatedata(uid);
                    }
                }

                private void updatedata(String uid) {
                        System.out.println(uid);
                        upatt.setVisible(true);
                        upmar.setVisible(true);
                        newupdate.setVisible(true);
                        newupdate.addActionListener(new ActionListener() {

                            @Override
                            public void actionPerformed(ActionEvent e) {

                            
                        try {
                        int at=Integer.parseInt(upatt.getText());
                        int ma=Integer.parseInt(upmar.getText());
                        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/q3","root","1234");
                        Statement smt=con.createStatement();
                        String sql="update "+facultysub+" set attendance = "+at+", marks ="+ma+" where uname='"+uid+"'";
                        System.out.println(sql);
                        smt.executeUpdate(sql);
                        System.out.println("result updated");
                        //prepareGui();
                        //showdata();
                        record.setVisible(true);
                        } catch (SQLException ex) {
                            Logger.getLogger(faculty.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        }
                        });
                }
            });
            p.add(l1);
            p.add(id);
            p.add(enter);
          //  mainframe.setVisible(true);
    }

  private void showdata() {
             
            l1.setVisible(false);
            id.setVisible(false);
            enter.setVisible(false);
            upatt.setVisible(false);
            upmar.setVisible(false);
            record.setVisible(false);
            newupdate.setVisible(false);
            
       try {
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/q3","root","");
           Statement smt=con.createStatement();
           String sql="select * from faculty where uname ='"+funame+"'";
           ResultSet rs=smt.executeQuery(sql);
           if(rs.next())
           {
               System.out.println("Inside If");
               facultysub=rs.getString("subject");
               String sql1="select * from "+facultysub;
               Statement stmt=con.createStatement();
               Statement co=con.createStatement();
               ResultSet newrs=stmt.executeQuery(sql1);
               ResultSet count=co.executeQuery(sql1);
               int lc=0,hight=0;
               while(count.next())
               {
                   lc++;
               }
               String data[][]=new String[lc][3];
               String column[]={"ID","ATTENDANCE","MARKS"};               
              // JOptionPane.showMessageDialog(null, lc);
               lc=0;
               while(newrs.next())
               {
                   hight+=18;
                   data[lc][0]=newrs.getString("uname");
                   data[lc][1]=newrs.getString("attendance");
                   data[lc][2]=newrs.getString("marks");
                   lc++;
               }
               table =new JTable(data,column);
              // table.setBounds(100 ,100,800,hight);
                sp=new JScrollPane(table);
               sp.setBounds(300,100,400, 700);
               p.add(sp);
               mainframe.setVisible(true);
           }
           else
           {
               // not
           }
               
           
       } catch (SQLException ex) {
           Logger.getLogger(faculty.class.getName()).log(Level.SEVERE, null, ex);
       }
  
  }
       
    private void showGui() {
        
        mainframe.setVisible(true);
    
    }
    /*
    public static void main(String[] args) {
        faculty f=new faculty("arun");
    }*/
}