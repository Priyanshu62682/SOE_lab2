/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q3;
import com.sun.java.swing.plaf.windows.resources.windows;
import java.util.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
/**
 *
 * @author NITIN KUMAR
 */
public class login {
    private JFrame mainframe;
    private JLabel username;
    private JLabel password;
    private JTextField uname;
    private JTextField pass;
    private JButton sbtn;
    
    
    
    String un,ps;
    
    public login(){
        prepareGui();
}
    public static void main(String[] args) {
        
           login att=new login();
            att.showGui();
        
    }
    private void prepareGui() {
        //To change body of generated methods, choose Tools | Templates.
        mainframe = new JFrame("Login");
        mainframe.setSize(1000,700);
        mainframe.setLayout(null);
        mainframe.setResizable(false);
        mainframe.addWindowListener(new  WindowAdapter() {
            
            public void windoClosing(WindowEvent we)
            {
                System.exit(0);
            }
            
});
    
        username= new JLabel("User Name");
        username.setBounds(200,300,300, 20);
        username.setFont(new Font(username.getName(),Font.PLAIN,29));
        
        password=new JLabel("Password");
        password.setBounds(200, 340, 300, 20);
        password.setFont(new Font(password.getName(),Font.PLAIN,29));
        
        uname= new JTextField("Enter User Name");
        uname.setBounds(440, 300, 300, 29);
      
        pass = new JPasswordField("Enter");
        pass.setBounds(440, 340, 300, 29);
        
        sbtn=new JButton("Login");
        sbtn.setBounds(440, 380, 100, 50);
        sbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                loginbutton(e);
            }

            
        });
       
        mainframe.add(username);
        mainframe.add(password);
        mainframe.add(uname);
        mainframe.add(pass);
        mainframe.add(sbtn);
        mainframe.setVisible(true);
    
    }
   private void loginbutton(ActionEvent e1) {
              //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                
                               
        try{
            un=uname.getText(); 
            System.out.println(un);
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Not Valid User Name","Error",JOptionPane.ERROR_MESSAGE);
        }
        try{
            ps=pass.getText();
            if(ps.length()<6)
                JOptionPane.showMessageDialog(null, "password length must be >=6");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Not Valid Password","Error",JOptionPane.ERROR_MESSAGE);
        }            
        if(un.length()>0 && ps.length()>=6)
        {
            try {
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/q3","root","1234");
                Statement smt =con.createStatement();
               // JOptionPane.showMessageDialog(null, "login "+un+"\n pass "+ps);
                String sql="select * from login where uname='"+un+"' and pass ='"+ps+"'";
                ResultSet rs = smt.executeQuery(sql);
                if(rs.next()) 
                {
                    //dispose();
                   // mainframe.main(null);
                    JOptionPane.showMessageDialog(null, "login");
                   // System.out.println("Login!!!");
                   if(rs.getInt("pri")==1)
                   {
                       //student
                       System.out.println("Student!!!");
                       student std=new student(un);
                       mainframe.setVisible(false);
                   }
                   else if(rs.getInt("pri")==2)
                   {
                       //teacher
                       System.out.println("teacher!!!");
                       faculty fec=new faculty(un);
                       mainframe.setVisible(false);
                       
                   }
                   else
                   {
                       //dean
                       new dean();
                       System.out.println("Dean!!!");
                       mainframe.setVisible(false);
                   }
                
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "bye");
                    //jLabel1.setText("Enter Valid username & password");
                    System.out.println("bye");
                }
            } catch (SQLException ex) {
                Logger.getLogger(ques3.login.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
   
   }

     void showGui() {
                mainframe.setVisible(true);
    }
    
}