/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package q3;

/**
 *
 * @author Nitin Kumar
 */
import java.util.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
public class student {
    
    private JFrame stdframe;
    private JPanel p;
    private JLabel roll,name;
    private JTable table;
    private JScrollPane sp;
    static String uname,sub1,sub2,sub3,sname;
    private JButton logout;
    public student(String un)
    {
        uname=un;
        prepareGui();
    }

    private void prepareGui() {
        
        stdframe =new JFrame("Student");
        p=new JPanel();
        stdframe.setContentPane(p);
        stdframe.setSize(1000,700);
        stdframe.setLayout(null);
        stdframe.setResizable(true);
        roll=new JLabel("ROLL NO. = "+uname.toUpperCase());
        roll.setBounds(300,20,180,30);
        roll.setVisible(true);
        logout=new JButton("logout");
        logout.setBounds(900, 610, 80, 30);
        logout.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

               logoff();
            }

            private void logoff() {
                login lg=new login();
                lg.showGui();
                stdframe.setVisible(false);
            }
        });
        p.add(logout);
        p.add(roll);
       // p.add(name);
        
        stdframe.addWindowListener(new WindowAdapter() {
          
            public void windowCloser(WindowEvent e)
            {
                System.exit(0);
            }
        
        });
        showdata();
        stdframe.setVisible(true);
        
    
    }

    private void showdata() {
    
        try { 
            String data[][]=new String[3][4];
            String column[]={"Subject","Attendance","Marks"}; 
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/q3","root","1234");
            Statement smt=con.createStatement();
            String sql="select * from student where uname ='"+uname+"'";
            System.out.println(sql+" 1");
            ResultSet rs=smt.executeQuery(sql);
            if(rs.next())
            {
                System.out.println("Inside Student If");
                sname=rs.getString("NAME");
                sub1=rs.getString("SUB1");
                sub2=rs.getString("SUB2");
                sub3=rs.getString("SUB3");
            }
            Statement smt1=con.createStatement();
            sql="select * from "+sub1+" where uname = '"+uname+"'";
            System.out.println(sql+" 2");
            rs=smt1.executeQuery(sql);
            if(rs.next())
            {
                String propersub=getProperNameOfSubject(sub1);
                data[0][0]=propersub;
                data[0][1]=rs.getString("attendance");
                data[0][2]=rs.getString("marks");
                System.out.println(rs.getString("attendance")+" "+rs.getString("marks"));  
            }
            Statement smt2=con.createStatement();
            sql="select * from "+sub2+" where uname = '"+uname+"'";
            System.out.println(sql+" 3");
            rs=smt2.executeQuery(sql);
            if(rs.next())
            {
                String propersub=getProperNameOfSubject(sub2);
                data[1][0]=propersub;
                data[1][1]=rs.getString("attendance");
                data[1][2]=rs.getString("marks");
                System.out.println(rs.getString("attendance")+" "+rs.getString("marks"));
            }
            Statement smt3=con.createStatement();
            sql="select * from "+sub3+" where uname = '"+uname+"'";
            System.out.println(sql+" 4");
            rs=smt3.executeQuery(sql);
            if(rs.next())
            {
                String propersub=getProperNameOfSubject(sub3);
                data[2][0]=propersub;
                data[2][1]=rs.getString("attendance");
                data[2][2]=rs.getString("marks");
                System.out.println(rs.getString("attendance")+" "+rs.getString("marks"));
            }
            table =new JTable(data,column);
            
            sp=new JScrollPane(table);
            sp.setBounds(250,60,500, 700);
            p.add(sp);
            name=new JLabel("NAME = "+sname.toUpperCase());
        name.setBounds(500,20,150,30);
        name.setVisible(true);
        p.add(name);
         //   stdframe.setVisible(true);
            System.out.println("Happy");
        } catch (Exception ex) {
            Logger.getLogger(student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /*
    public static void main(String[] args) {
        new student("rit2014003");
    }*/

    private String getProperNameOfSubject(String sub1) {
        
        if(sub1.equalsIgnoreCase("soe"))
            return "Software Engineering";
        else if(sub1.equalsIgnoreCase("cn"))
            return "Computer Networks";
        else if(sub1.equalsIgnoreCase("ai"))
            return "Artificial Inteligence";
        else if(sub1.equalsIgnoreCase("poe"))
            return "Principle Of Economics";
        else if(sub1.equalsIgnoreCase("gvc"))
            return "Graphics";
        else
            return "";
        
    }
}