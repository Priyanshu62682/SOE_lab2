package q3;
import java.util.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
public class dean {
    private JFrame dframe;
    private JPanel p;
    private JTable table;
    private JScrollPane sp;
    private JButton logout;
    public dean()
    {
        prepareGui();
        showGui();
        showdata();
    }

    private void prepareGui() {

        dframe=new JFrame("Dean");
        p=new JPanel();
        dframe.setContentPane(p);
        dframe.setSize(1500, 700);
        dframe.setResizable(true);
        dframe.setLayout(null);
        logout=new JButton("logout");
        logout.setBounds(1250, 610, 80, 30);
        logout.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

               logoff();
            }

            private void logoff() {
                login lg=new login();
                lg.showGui();
                dframe.setVisible(false);
            }
        });
        p.add(logout);
        dframe.setVisible(true);
    
    }
    /*
    public static void main(String[] args) {
        new dean();
    }*/

    private void showGui() {
        dframe.setVisible(true);
    }

    private void showdata() {

        try {
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/q3","root","1234");
            Statement smt=con.createStatement();
            ResultSet rs=smt.executeQuery("select * from student");
            int lc=0;
            while(rs.next())
            {
                
                lc++;
            }
            //System.out.println(lc);
            String data[][]=new String[lc][10];
            String column[]={"id","Subject 1","Attendance 1","Marks 1","Subject 2","Attendance 2","Marks 2","Subject3","Attendance 3","Marks 3"};
            Statement stmt=con.createStatement();
            ResultSet r1=stmt.executeQuery("select * from student");
            lc=0;
            while(r1.next())
            {
               
                
                data[lc][0]=r1.getString("uname");
                data[lc][1]=getProperNameOfSubject(r1.getString("SUB1"));
                data[lc][4]=getProperNameOfSubject(r1.getString("SUB2"));
                data[lc][7]=getProperNameOfSubject(r1.getString("SUB3"));
                System.out.println(data[lc][0]);
                Statement stmt1=con.createStatement();
                String sql1="select * from "+r1.getString("SUB1")+" where uname='"+data[lc][0]+"'";
                
                ResultSet rs1=stmt1.executeQuery(sql1);
                if(rs1.next())
                {
                    data[lc][2]=rs1.getString("attendance");
                    data[lc][3]=rs1.getString("marks");
                }
                Statement stmt2=con.createStatement();
                String sql2="select * from "+r1.getString("SUB2")+" where uname='"+data[lc][0]+"'";
                ResultSet rs2=stmt2.executeQuery(sql2);
                if(rs2.next())
                {
                    data[lc][5]=rs2.getString("attendance");
                    data[lc][6]=rs2.getString("marks");
                }
                
                Statement stmt3=con.createStatement();
                String sql3="select * from "+r1.getString("SUB3")+" where uname='"+data[lc][0]+"'";
                ResultSet rs3=stmt3.executeQuery(sql3);
                if(rs3.next())
                {
                    data[lc][8]=rs3.getString("attendance");
                    data[lc][9]=rs3.getString("marks");
                }
                lc++;
                System.out.println("loop"+lc);
            } 
            System.out.println("OutSide while");
            con.close();
            table =new JTable(data,column);
                sp=new JScrollPane(table);
               sp.setBounds(0,0,1350,600);
               p.add(sp);
              // dframe.setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(dean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private String getProperNameOfSubject(String sub1) {
        
        if(sub1.equalsIgnoreCase("soe"))
            return "Software Engineering";
        else if(sub1.equalsIgnoreCase("cn"))
            return "Computer Networks";
        else if(sub1.equalsIgnoreCase("ai"))
            return "Artificial Inteligence";
        else if(sub1.equalsIgnoreCase("poe"))
            return "Principle Of Economics";
        else if(sub1.equalsIgnoreCase("gvc"))
            return "Graphics";
        else
            return "";
        
    }
}