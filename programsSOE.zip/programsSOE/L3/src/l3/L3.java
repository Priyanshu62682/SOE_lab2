package l3;
import java.sql.*;
import java.util.*;
import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
class L3 extends Frame implements ActionListener 
{
    TextField t1,t2;
    L3()
    {
        t1=new TextField();
        t1.setBounds(400, 200, 100, 30);
        add(t1);
        setSize(800,800);
        setLayout(null);
        setVisible(true);
        Label l1=new Label("Email id");
        l1.setBounds(200,200,100,30);
        add(l1);
        Label l2=new Label("password");
        l2.setBounds(200,300,100,30);
        add(l2);
        t2=new TextField();
        t2.setBounds(400,300,100,30);
         t2.setEchoChar('*');
        add(t2);
        Button b = new Button("send");
        b.setBounds(350,350,80,30);
        add(b);
        b.addActionListener(this); 
        setBackground(Color.pink);
    }
    public void actionPerformed(ActionEvent e)
    {
        Connection con=null;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/las3","root","smita");
            System.out.println("database successfully connected");
        }
        catch(Exception e1)
        {
            System.out.println("error1");
        }
        try
        {
            Statement st=con.createStatement();
            String s1=t1.getText();
            variables.id=s1;
            String s2=t2.getText();
            System.out.println(s1);
            String q1="select * from priveleges where email_id = '"+s1+"' ";    
            ResultSet rs=st.executeQuery(q1);
            rs.next();
            String s3=rs.getString("password");
            String s4=rs.getString("privelege");
            System.out.println(s3);
            System.out.println(s4);
            if(s2.equals(s3) && s4.equals("t"))
            {
                Button1 bu=new Button1();
                bu.setVisible(true);
                this.setVisible(false);
                
            }    
            else
            {
                Label l3=new Label("incorrect passwrd");
                l3.setBounds(350,450,100,40);
                add(l3);
            }
        }
        catch(Exception e2)
        {
            System.out.println("error2");
        }
        
        
    }  
    public static void main(String[] args)
    {
      new L3();
    } 
}
