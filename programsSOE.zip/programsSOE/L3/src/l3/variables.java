package l3;
public class variables
{
    public static String id;
}