package l3;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;

class Table5 extends JFrame 
{
    private final    JPanel    topPanel;
    private final    JTable    table;
    private final    JScrollPane scrollPane;
    private final    JButton     button;
    public Table5()
    {
        setSize( 500,500  );
        setBackground( Color.gray );
        topPanel = new JPanel();
        topPanel.setLayout( new BorderLayout() );
        Container con=getContentPane();
        con.add( topPanel , BorderLayout.CENTER);
        table=new JTable(30,4);
        String header[] = {"StudentID", "TEST1", "TEST2", "ATTENDANCE"};
        for(int i=0;i<table.getColumnCount();i++)
        {
            javax.swing.table.TableColumn column1 = table.getTableHeader().getColumnModel().getColumn(i);
            column1.setHeaderValue(header[i]);
        }
        try
        {
            
           Class.forName("com.mysql.jdbc.Driver");
           Connection con2 =DriverManager.getConnection("jdbc:mysql://localhost/las3", "root","smita");
           Statement stmt=con2.createStatement();
           String s2;
           int row=0;
           s2="select * from dsa;";
           ResultSet rs=stmt.executeQuery(s2);
           while(rs.next())
           {
               table.setValueAt(rs.getString("email_id"),row,0);
               table.setValueAt(rs.getString("ct1"),row,1);
               table.setValueAt(rs.getString("ct2"),row,2);
               table.setValueAt(rs.getString("attendance"),row,3);
               row++;
           }
        }
        catch(Exception e1)
        {
                    System.out.println("error");
        }
        scrollPane = new JScrollPane( table );
        topPanel.add( scrollPane, BorderLayout.CENTER );
                JPanel panel=new JPanel();
                panel.setLayout(new FlowLayout());
                button=new JButton("update");
                panel.add(button);
                con.add(panel, BorderLayout.SOUTH);
                
    }
     public void action()
    {
        button.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e)
           {
               try{
                  Class.forName("com.mysql.jdbc.Driver");
            Connection con3=DriverManager.getConnection("jdbc:mysql://localhost/las3", "root","smita");
           Statement stmt=con3.createStatement(); 
           String s,s1;
           int row=0;
           float t1,t2;
           int a;
           while(table.getValueAt(row, 0)!=null)
            {
               s1=(String)table.getValueAt(row,0);
               t1=Float.parseFloat((String)table.getValueAt(row,1));
               t2=Float.parseFloat((String)table.getValueAt(row,2));
               a=Integer.parseInt((String)table.getValueAt(row,3));
               System.out.println(s1);
               System.out.println(t1);
               System.out.println(t2);
               System.out.println(a);
               s="update "+dsa+" set ct1="+t1+", ct2="+t2+", attendance="+a+" where email_id='"+s1+"'";
               stmt.executeUpdate(s);
               row++;
            }
            
               }
                 catch(   NullPointerException | ClassNotFoundException | SQLException e1)
        {
            System.out.println(e1);
        } 
           }
        });
    }

    public static void main( String args[] )
    {
        Table5 mainFrame = new Table5();
        mainFrame.setVisible( true );
    }
}