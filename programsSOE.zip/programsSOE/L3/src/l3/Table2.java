package l3;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import javax.swing.*;
class Table2 extends JFrame
{
    private JPanel tp;
    private JScrollPane sp;
    private JTable table;
    private JButton button;
    Table2
    {
        setSize(500,500);
        setBackground(Color.yellow);
        tp = new JPanel();
        tp.setLayout(new BorderLayout());
        Container con=getContentPane();
        con.add(tp,BorderLayout.CENTER);
        table=new JTable(30,4);
         String header[] = {"StudentID", "TEST1", "TEST2", "ATTENDANCE"};
        for(int i=0;i<table.getColumnCount();i++)
        {
            javax.swing.table.TableColumn column1 = table.getTableHeader().getColumnModel().getColumn(i);
            column1.setHeaderValue(header[i]);
        }
        try
        {
            
           Class.forName("com.mysql.jdbc.Driver");
           Connection con2 =DriverManager.getConnection("jdbc:mysql://localhost/las3", "root","smita");
           Statement stmt=con2.createStatement();
           String s2;
           int row=0;
           s2="select * from mat;";
           ResultSet rs=stmt.executeQuery(s2);
           while(rs.next())
           {
               table.setValueAt(rs.getString("email_id"),row,0);
               table.setValueAt(rs.getString("ct1"),row,1);
               table.setValueAt(rs.getString("ct2"),row,2);
               table.setValueAt(rs.getString("attendance"),row,3);
               row++;
           }
        }
        catch(Exception e1)
        {
                    System.out.println("error");
        }
        sp=new JScrollPane(table);
        tp.add(sp,BorderLayout.CENTER);
        JPanel j=new JPanel();
        j.setLayout(new FlowLayout());
        button = new JButton("update");
        j.add(button);
        con.add(j, BorderLayout.SOUTH);  
    }
     public void action()
    {
        button.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e)
           {
               try{
                  Class.forName("com.mysql.jdbc.Driver");
            Connection con3=DriverManager.getConnection("jdbc:mysql://localhost/las3", "root","smita");
           Statement stmt=con3.createStatement(); 
           String s,s1;
           int row=0;
           float t1,t2;
           int a;
           while(table.getValueAt(row, 0)!=null)
            {
               s1=(String)table.getValueAt(row,0);
               t1=Float.parseFloat((String)table.getValueAt(row,1));
               t2=Float.parseFloat((String)table.getValueAt(row,2));
               a=Integer.parseInt((String)table.getValueAt(row,3));
               System.out.println(s1);
               System.out.println(t1);
               System.out.println(t2);
               System.out.println(a);
               s="update "+mat+" set ct1="+t1+", ct2="+t2+", attendance="+a+" where email_id='"+s1+"'";
               stmt.executeUpdate(s);
               row++;
            }
            
               }
                 catch(   NullPointerException | ClassNotFoundException | SQLException e1)
        {
            System.out.println(e1);
        } 
           }
        });
    }

    public static void main(String[] args)
    {
        Table2 mainframe = new Table2();
        mainframe.setVisible(true);
        
    }
}