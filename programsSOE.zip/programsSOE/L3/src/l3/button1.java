package l3;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
class Button1 extends Frame implements ActionListener
{
   
    public Button1()
    {
        try
        {
            setSize(1000,500);
            setVisible(true);
            setLayout(null);
            Connection con=null;
            
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/las3","root","smita");
            System.out.println("database connected");
            Statement st=con.createStatement(); 
            
         
            String s5=variables.id;
               System.out.println(s5);
            String q1="select subject from subjects where email_id='"+s5+"'";
            ResultSet rs= st.executeQuery(q1);
           // int c=rs.getRow();
            String a = null,b,c;
            while(rs.next())
            {
                a=rs.getString("subject");
                System.out.println(a);
                if(!a.equals(null))
                {
                    Button b1=new Button(a);
                    b1.setBounds(400,300,50,30);
                    add(b1);
                    b1.addActionListener(this);
                }
                rs.next();
                b=rs.getString("subject");
                System.out.println(b);
                if(!b.equals(null))
                {
                    Button b2=new Button(b);
                    b2.setBounds(500,300,50,30);
                    add(b2);
                    b2.addActionListener(this);
                }
                rs.next();
                c=rs.getString("subject");
                System.out.println(c);
                if(!c.equals(null))
                {
                    Button b3=new Button(b);
                    b3.setBounds(500,300,50,30);
                    add(b3);
                    b3.addActionListener(this);
                }
                 if(!rs.next())
                     break;
            }
            
        }
        catch(Exception e1)
        {
            
        }
        
    }
    public void actionPerformed(ActionEvent e)
    {
        String action=e.getActionCommand();
        if(action.equals("POE"))
        {
            
            Table1 t1=new Table1();
            t1.action();
            t1.setVisible(true);
            this.setVisible(false);
        }
        else if(action.equals("MAT"))
        {
            Table2 t2=new Table2();
            t2.action();
            t2.setVisible(true);
            this.setVisible(false);
        }
        else if(action.equals("COA"))
        {
            Table3 t3=new Table3();
            t3.action();
            t3.setVisible(true);
            this.setVisible(false);
        }
        else if(action.equals("DSA"))
        {
            Table4 t4=new Table4();
            t4.action();
            t4.setVisible(true);
            this.setVisible(false);
        }
        else if(action.equals("CNE"))
        {
            Table5 t5=new Table5();
            t5.action();
            t5.setVisible(true);
            this.setVisible(false);
        }
        else if(action.equals("POC"))
        {
            Table6 t6=new Table6();
            t6.action();
            t6.setVisible(true);
            this.setVisible(false);
        }
    }
    public static void main(String[] args)
    {
        new Button1();
    }
    
}
