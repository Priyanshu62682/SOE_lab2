#include<stdio.h>
int main()
{
	int i,j,k;
	scanf("%d",&i);
	printf("%d",i);
	return 0;
	c=sum(a,b);
}
int sum(int a,int b)
{
	printf("value of a"= %d\n,a);
}
