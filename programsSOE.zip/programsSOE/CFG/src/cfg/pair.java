
package cfg;

public class pair {
    int first,second;
    pair(int a,int b){
        this.first=a;
        this.second=b;
    }
    int get_first(){
        return this.first;
    }
    int get_second(){
        return this.second;
    }
}