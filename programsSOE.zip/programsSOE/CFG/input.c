
# include <stdio.h>
void fun(int a, int b, int y)
{

/*	    if(a>5) // last if last node
    {
        if()//last if last node
        {
            b = 5;//last statement
        }
        if(){
        	babab rocks;
        }
        else//connect to last if and remove it
        {
            if()//last if
            {
                s=o;//last statement
            }       
        }
        if(){
        	//bansal 1;
        }
    }
    else if()//connect to last node and set this to last node
    {
        //last statement
    }
    else//connect to last if and remove it
    {
        if()//last node and last if
        {
            if()//last node and last if
            {
                p=0;//last statement
            }
            //       
        }
           
       
    }
    while()//connect to all last statement and
    {
        yo;//last statement   
    }    
    */
   /*if()
   {
   		if()
   		{
   			a=w;
   		}
   		else if()
   		{
   			if()
   			{
   				w=e;
   			}
   		}
   		else
   		{
   			g=k;
   		}
   }
   if()
   {
   	s=o;
   }*/
   	/*if(a>5) // If statement
	{
	    if(a<3){
            bhaiko
	    }
		a = 3;
	}

    if(){
         
     }
	else if(a>d){
        a=12;
	}
	else
	{
		b = 5;
	}*/

/*for(1)
{ 
  rohan rox;
  if{
        for(2){
                if(){ }
        }
    }
  for(3){ }
}*/
	/*while(y < 20)
	{

	//Nested if condition inside while loop
    if(y == 3)
		{
			y++;
		}
		else if(y == 5)
		{
			y+=3;
		}
		
	} //End of while loop
    */
  /*if(){
       if(){
          while(){
           a=3;
          }
        }
        else if(){
            23
        }
        while(){
          if(){
            bhai bhai;
          }
        }
  }*/
        do{
                if(){
                    in1
                }
                else{
                  in2
                }
                while(){
                  in3
                }
        }while();

}
