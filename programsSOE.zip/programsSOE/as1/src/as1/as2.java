package as1;
import java.sql.*;
import java.util.Scanner;
public class as2 
{
    public static void main(String[] args) 
    {
        Connection con =null;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/university","root","1234");
            //System.out.println("database connected");
        }
        catch(Exception ex)
        {
               System.out.println(ex);
        }
        try
        {
            ResultSet rs =null;
          // Class.forName("com.mysql.jdbc.Driver");
          // Connection con = DriverManager.getConnection("jdbc:mysql://localhost/student","root","@#rit2014048");
           Statement st= con.createStatement();
           Scanner in=new Scanner(System.in);
           while(true)
           {
               System.out.println("1.insert");
               System.out.println("2. delete");
               System.out.println("3. update");
               System.out.println("4. edit");
               System.out.println("5. ascending");
               System.out.println("6. search");
               System.out.println("7. sort and display");
               System.out.println("8. exit");
                int choice;
                choice=in.nextInt();
                switch(choice)
                { 
                    case 1 :
                       System.out.println("enter values to be inserted");
                       System.out.println("id,'name','fname','address',age,'mobno.',CGPA");
                       System.out.println("enter id");
                        int id=in.nextInt();
                        System.out.println("enter name");
                        String y=in.nextLine();
                        String name=in.nextLine();
                        System.out.println("enter f_name");
                        String f_name=in.nextLine();
                        System.out.println("enter address");
                        String address=in.nextLine();
                        System.out.println("enter age");
                        int age=in.nextInt();
                        System.out.println("enter mob-no");
                        String yfd=in.nextLine();
                         String mob_no=in.nextLine();
                        System.out.println("enter cgpa");
                        float cgpa=in.nextFloat();
                        String yf=in.nextLine();
                        String q1="insert into studentdb values ("+id+",'"+name+"','"+f_name+"','"+address+"',"+age+",'"+mob_no+"',"+cgpa+");";
                        st.execute(q1);
                        
                        break;
                    case 2 :
                         System.out.println("enter id");
                        int num=in.nextInt();
                      String q2 ="delete from studentdb where id="+num+";";
                        st.execute(q2);
                        break;
                    case 3 :  
                        System.out.println("enter value 1. name , 2. fname ,3. address, 4. age, 5.mobno,6. cgpa");
                        int ch=in.nextInt();
                        switch(ch)
                        {
                            case 1:
                                System.out.println("enter id for name change");
                                int number=in.nextInt();
                                System.out.println("enter changed name ");
                                String stri=in.nextLine();
                                String str=in.nextLine();
                                String q3 ="update studentdb set name='"+str+"' where id="+number+";";
                                st.execute(q3);
                                break;
                            case 2:
                                System.out.println("enter id for fathername change");
                                int numbe=in.nextInt();
                                System.out.println("enter changed name ");
                                String strib=in.nextLine();
                                String so=in.nextLine();
                                String q4 ="update studentdb set fname='"+so+"' where id="+numbe+";";
                                st.execute(q4);
                                break;
                            case 3:
                                System.out.println("enter id for address change");
                                int numb=in.nextInt();
                                System.out.println("enter changed address ");
                                String sto=in.nextLine();
                                String sot=in.nextLine();
                                String q5 ="update studentdb set address='"+sot+"' where id="+numb+";";
                                st.execute(q5);
                                break;
                            case 4:
                                System.out.println("enter id for age change");
                                int nu=in.nextInt();
                                System.out.println("enter changed age ");
                                int chnu=in.nextInt();
                                String q6 ="update studentdb set age="+chnu+" where id="+nu+";";
                                st.execute(q6);
                                break;
                
                            case 5:
                                System.out.println("enter id for mobno change");
                                int numbr=in.nextInt();
                                System.out.println("enter changed number ");
                                String stot=in.nextLine();
                                String sotn=in.nextLine();
                                String q7 ="update studentdb set address='"+sotn+"' where id="+numbr+";";
                                st.execute(q7);
                                break;
                            case 6:
                                System.out.println("enter id for cgpa change");
                                int nup=in.nextInt();
                                System.out.println("enter changed cgpa ");
                                int chnup=in.nextInt();
                                String q8 ="update studentdb set age="+chnup+" where id="+nup+";";
                                st.execute(q8);
                                break;
                            case 7 :
                            break;
                        }
                    case 4 :
                        System.out.println("enter column name to added");
                        String sotnt=in.nextLine();
                        String stn=in.nextLine();
                        System.out.println("enter data type of column");
                       // String sttn=in.nextLine();
                        String stpn=in.nextLine();
                        String q8 ="alter table studentdb add "+stn+" "+stpn+";";
                        st.execute(q8);
                        break;
                    case 5:
                        //String tr1=in.nextLine();
                        //String tr2=in.nextLine();
                       // int tr3=in.nextInt();
                        String tr4="select * from studentdb order by name desc,age desc;";
                        rs=st.executeQuery(tr4);
                        System.out.println("Table Contents are sorted by name and age");
                        while(rs.next())   
                        {
                            int dt1= Integer.parseInt(rs.getString("id"));
                            String name12=rs.getString("name");
                            String name13=rs.getString("fname");
                            String name14=rs.getString("address");
                            int age5=Integer.parseInt(rs.getString("age"));
                             String num5 = rs.getString("mobno");
                            float pointer5 = Float.parseFloat(rs.getString("cgpa"));
                            System.out.println(dt1+"  "+name12+"   "+name13+"    "+name14+"  "+age5+"   "+num5+"   "+pointer5);
                        }
                         String s7=in.nextLine();
                       /* String query8="select * from studentdb order by "+s7+" ";
                        ResultSet rs1 = st.executeQuery(query8);
                        System.out.println("Table contents after sortedby age");
                        System.out.println("id  name  fathers_name age address mobile_no. address");
                         while (rs1.next())
                         {
                           int id5 = Integer.parseInt(rs1.getString("id"));
                           String name1 = rs1.getString("name");
                           String name2 = rs1.getString("fname");
                           String name3 = rs1.getString("address");
                           int age5 = Integer.parseInt(rs1.getString("age"));
                           int num5 = Integer.parseInt(rs1.getString("mobno"));
                           String pointer5 = rs1.getString("cgpa");
                           System.out.println(id5+"   "+name1+"    "+name2+"  "+name3+"  "+age5+"   "+num5+"   "+pointer5);
                         }*/
                        break;
                    case 6:
                        //String e3=in.nextLine();
                       // String s6=in.nextLine();
                        System.out.println("enter id for searching information");
                        int s0=in.nextInt();
                        String q11 ="select * from studentdb where id="+s0+";";
                        ResultSet rs5=null;
                             rs5 = st.executeQuery(q11);
                            rs5.next();
                            System.out.println("id  name  fathers_name  address age mobile_no. address");
                                int id5 = Integer.parseInt(rs5.getString("id"));
                                String name32 = rs5.getString("name");
                                String name20 = rs5.getString("fname");
                                int age54 = Integer.parseInt(rs5.getString("age"));
                                String name30 = rs5.getString("address");
                                String num59 = rs5.getString("mobno");
                                float pointer51 = Float.parseFloat(rs5.getString("cgpa"));
                                System.out.println(id5+"   "+name32+"    "+name20+"   "+name30+"  "+age54+"  "+num59+"   "+pointer51);
                        break;
                    case 7:
                        System.exit(0);
                 }
            }
        }
        catch(Exception e)
         {
            System.out.println("exception : "+ e);    
          }
    }
    
}
