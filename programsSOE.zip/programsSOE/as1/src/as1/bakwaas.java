package as1;
import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
class bakwass
{
    
    public static void main( String args[] )
    {
        int count=0;
      String l = "int a=1,b=4,g=5;";
      
       String var1 = "(\\w)((\\s)*"+"="+"(\\s)*(.*))*";
       String pattern = "(int|char|double|float)"+"(\\s)+"+var1;
      
      Pattern r = Pattern.compile(pattern);
      Matcher m = r.matcher(l);
   /*   while (m.find())
      {
            System.out.println(l.substring(m.start(),m.end()));
            count++;
        }
        System.out.println("Count of Functions:"+count);*/
      
      if (m.find( )) 
      {
         System.out.println("Found value: " + m.group(0) );
         System.out.println("Found value: " + m.group(1) );
         System.out.println("Found value: " + m.group(2) );
         System.out.println("Found value: " + m.group(3) );
         System.out.println("Found value: " + m.group(4) );
         System.out.println("Found value: " + m.group(5) );
         System.out.println("Found value: " + m.group(6) );
         System.out.println("Found value: " + m.group(7) );
         System.out.println("Found value: " + m.group(8) );
         System.out.println("Found value: " + m.group(9) );
         System.out.println("Found value: " + m.group(10) );
      } 
      else 
      {
         System.out.println("NO MATCH");
      }
   }
}