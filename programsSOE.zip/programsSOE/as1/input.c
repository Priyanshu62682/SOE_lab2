#include<stdio.h>
int main()
{
	int i,j,k;
	scanf("%d",&i);
	printf("%d",i);
	return 0;
}
